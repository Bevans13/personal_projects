package Creatures;

import java.util.ArrayList;

import Items.*;

public class Creature {
    
private int health, damageResistance, actionPoints, currentHealth;
private double carryWeightLimit, currentCarryWeight;
private ArrayList<Items> inventory;

public Creature(int h, int dr, int ap, double cw){
    health = h;
    damageResistance = dr;
    actionPoints = ap;
    carryWeightLimit = cw;
}

public void takeDamage(int damage){
    health -= damage;
}

public void useActionPoints(int pointsUsed){
    actionPoints -= pointsUsed;
}

public void display(){
    System.out.println(health+" "+damageResistance+" "+actionPoints+" "+carryWeightLimit);
}

public int getActionPoints() {
    return actionPoints;
}public void setActionPoints(int actionPoints) {
    this.actionPoints = actionPoints;
}public double getCarryWeightLimit() {
    return carryWeightLimit;
}public void setCarryWeightLimit(double carryWeight) {
    this.carryWeightLimit = carryWeight;
}public int getDamageResistance() {
    return damageResistance;
}public void setDamageResistance(int damageResistance) {
    this.damageResistance = damageResistance;
}public int getHealth() {
    return health;
}public void setHealth(int health) {
    this.health = health;
}public double getCurrentCarryWeight() {
    return currentCarryWeight;
}public void setCurrentCarryWeight(double currentCarryWeight) {
    this.currentCarryWeight = currentCarryWeight;
}public ArrayList<Items> getInventory() {
    return inventory;
}public void setInventory(ArrayList<Items> inventory) {
    this.inventory = inventory;
}public int getCurrentHealth() {
    return currentHealth;
}public void setCurrentHealth(int currentHealth) {
    this.currentHealth = currentHealth;
}

}