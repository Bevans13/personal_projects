package Creatures;
public class Player extends Creature {
    
    private String name;
    private int strength, perception, endurance, charisma, intelligence, agility,
    luck, level, smallGuns, bigGuns, magicalEnergyWeapons, meleeWeapons,
    unarmed, explosives;

    public Player(String n, int s, int p, int e, int c, int i,
    int a, int l, int lvl, int h, int sg, int bg, int mew,
    int melee, int un, int expl, int dr, int ap,
    double cw) {
        super(h, dr, ap, cw);
        name = n; 
        strength = s;
        perception = p;
        endurance = e;
        charisma = c;
        intelligence = i;
        agility = a;
        luck = l;
        level = lvl;
        smallGuns = sg;
        bigGuns = bg;
        magicalEnergyWeapons = mew;
        meleeWeapons = melee;
        unarmed = un;
        explosives = expl;

        //Loop to populate String 

    }

    @Override
    public void display() {
        super.display();
        System.out.println(name+" "+strength+" "+perception+" "+
        endurance+" "+charisma+" "+intelligence+" "+agility+" "+
        luck+" "+level+" "+smallGuns+" "+bigGuns+" "+magicalEnergyWeapons+" "+
        meleeWeapons+" "+unarmed+" "+explosives);
    }

    public String getName() {
        return name;
    } public void setName(String name) {
        this.name = name;
    } public int getStrength() {
        return strength;
    } public void setStrength(int strength) {
        this.strength = strength;
    } public int getPerception() {
        return perception;
    } public void setPerception(int perception) {
        this.perception = perception;
    } public int getEndurance() {
        return endurance;
    } public void setEndurance(int endurance) {
        this.endurance = endurance;
    } public int getCharisma() {
        return charisma;
    } public void setCharisma(int charisma) {
        this.charisma = charisma;
    } public int getIntelligence() {
        return intelligence;
    } public void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    } public int getAgility() {
        return agility;
    } public void setAgility(int agility) {
        this.agility = agility;
    } public int getLuck() {
        return luck;
    } public void setLuck(int luck) {
        this.luck = luck;
    } public int getLevel() {
        return level;
    } public void setLevel(int level) {
        this.level = level;
    } public int getSmallGuns() {
        return smallGuns;
    } public void setSmallGuns(int smallGuns) {
        this.smallGuns = smallGuns;
    } public int getBigGuns() {
        return bigGuns;
    } public void setBigGuns(int bigGuns) {
        this.bigGuns = bigGuns;
    } public int getMagicalEnergyWeapons() {
        return magicalEnergyWeapons;
    } public void setMagicalEnergyWeapons(int magicalEnergyWeapons) {
        this.magicalEnergyWeapons = magicalEnergyWeapons;
    } public int getMeleeWeapons() {
        return meleeWeapons;
    } public void setMeleeWeapons(int meleeWeapons) {
        this.meleeWeapons = meleeWeapons;
    } public int getUnarmed() {
        return unarmed;
    } public void setUnarmed(int unarmed) {
        this.unarmed = unarmed;
    } public int getExplosives() {
        return explosives;
    }public void setExplosives(int explosives) {
        this.explosives = explosives;
    }
}
