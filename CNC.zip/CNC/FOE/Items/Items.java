package Items;

public class Items {
    
    private double carryWeight;

    public Items(double cw){
        carryWeight = cw;
    }

    public double getCarryWeight() {
        return carryWeight;
    }public void setCarryWeight(double carryWeight) {
        this.carryWeight = carryWeight;
    }
}
