package Creatures;

public class Chalicotherium extends Creature {
    
    public Chalicotherium(String n, String sp, char gen, double health, double stam, double oxy,
    double f, double w, double mel, double move, double torp, Variation v){
        super(n, sp, gen, health, stam, oxy, f, w, mel, move, torp, v);
    }
}
