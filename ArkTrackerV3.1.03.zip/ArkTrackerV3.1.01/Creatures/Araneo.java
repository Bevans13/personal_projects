package Creatures;

public class Araneo extends Creature {
    
    public Araneo(String n, String sp, char gen, double health, double stam, double oxy,
    double f, double w, double mel, double move, double torp){
        super(n, sp, gen, health, stam, oxy, f, w, mel, move, torp);
    }

}
