import javax.swing.JPanel;
import java.awt.*;

public class UserInterfacePanel extends JPanel {
    
public UserInterfacePanel() {
    super();
}

public UserInterfacePanel(LayoutManager layout) {
    super(layout);
    
}

}
