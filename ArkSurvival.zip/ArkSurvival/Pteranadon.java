public class Pteranadon extends Creature {
    
    public Pteranadon(String n, String sp, double health, double stam, double oxy,
    double f, double w, double mel, double move, double torp){
        super(n, sp, health, stam, oxy, f, w, mel, move, torp);
    }

    
}
