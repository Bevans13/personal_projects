import java.io.*;
import java.util.*;

public class Driver {

    public static void main(String[] args) {
        
        BufferedReader br;
        BufferedWriter bw;

        // This string will contain the record being evaluated currently
        String record;
        // This array will hold the individual values for the current creature
        String [] fields;
        // Will track the total number of records (and thus the # of creatures)
        int recordCount;
        //An array to store the creature objects being read in to the program
        ArrayList<Creature> theIsland = new ArrayList<>();



        try {
            //instantiating br here to point to the input file
            br = new BufferedReader(new FileReader("dino_in.txt"));
            // instantiating bw here to point to the output file
            bw = new BufferedWriter(new FileWriter("dino_in.txt"));

            //reading the first record and storing it in the 'record' variable
            record = br.readLine();
            recordCount = 0;


            while (record != null) {
                
                // Instantiates the fields array and splits into separate strings for each 
                // value
                fields = splitDelimitedString(record, ",");

                // assign each position of the fields array to it's corresponding data
                String n = fields[0];
                String sp = fields[1];
                // the following fields are no longer actually strings so use Double method
                // to convert the fields values to double values
                double hp = Double.valueOf(fields[2]);
                double stam = Double.valueOf(fields[3]);
                double oxy = Double.valueOf(fields[4]);
                double f = Double.valueOf(fields[5]);
                double w = Double.valueOf(fields[6]);
                double mel = Double.valueOf(fields[7]);
                double mov = Double.valueOf(fields[8]);
                double torp = Double.valueOf(fields[9]);

                //5. Read the next record in the file
                    record = br.readLine();
                //Sort and create the creatures based on species
                switch (sp) {
                    case "Raptor":  
                        // change to contcatenate the new dino to the end of array
                        Raptor raptor = new Raptor(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                        theIsland.add(raptor);
                        break;
                    case "Rex":  
                        // change to contcatenate the new dino to the end of array
                        Rex rex = new Rex(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                        theIsland.add(rex);
                        break;
                    case "Parasaur":  
                        // change to contcatenate the new dino to the end of array
                        Parasaur parasaur = new Parasaur(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                        theIsland.add(parasaur);
                        break;
                    case "Pteranadon":  
                        // change to contcatenate the new dino to the end of array
                        Pteranadon pteranadon = new Pteranadon(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                        theIsland.add(pteranadon);
                        break;
                    
                    default:
                        break;
                }
                    recordCount++;
                    bw.newLine();
            }
                //Sort and create the creatures based on species
                switch (sp) {
                    case "Raptor":  
                        // change to contcatenate the new dino to the end of array
                        Raptor raptor = new Raptor(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                        theIsland.add(raptor);
                        break;
                    case "Rex":  
                        // change to contcatenate the new dino to the end of array
                        Rex rex = new Rex(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                        theIsland.add(rex);
                        break;
                    case "Parasaur":  
                        // change to contcatenate the new dino to the end of array
                        Parasaur parasaur = new Parasaur(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                        theIsland.add(parasaur);
                        break;
                    case "Pteranadon":  
                        // change to contcatenate the new dino to the end of array
                        Pteranadon pteranadon = new Pteranadon(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                        theIsland.add(pteranadon);
                        break;
                    
                    default:
                        break;
                }
                    recordCount++;
                    bw.newLine();
            }
            recordCount++;
            bw.newLine();
        }
        
        br.close();
        bw.flush();
        bw.close();
    }// End of Try Block which will read existing file
    
    catch (IOException ioe) 
    {
        System.out.println("IO Exception Error");
    }
    char select = 's';
        //While loop to allow user to select action until they want to exit
        while (select != 'E') {
            Scanner sc = new Scanner(System.in);
            //prompts user request for next steps
            System.out.println("Select to Add/Delete/View a creature(A/D/V/E): ");
            select=Character.toUpperCase(sc.next().charAt(0));
            //Separates what will occur based on user selection
            switch (select) {
                case 'A':
                System.out.println("Add");
                
                break;
                case 'D':
                System.out.println("Delete");
                break;
                case 'V':
                System.out.println("View");
                
                break;
                case 'E':  
                System.out.println("Exit App");
                break;
                default:
                System.out.println("Invalid entry");
                    break;
            } 
        }
    }
    
    
    
    
    
    public static String [] splitDelimitedString (String toSplit, String delimiter) 
    {
        //toSplit is the entire delimited String to be used to populate the array of values
        //
        //delimiter is the character used to separate the values in toSplit
        //     for a comma-delimited file, this argument will be the String ","
        
        String [] valuesAsStrings = toSplit.split(delimiter);
        
        return valuesAsStrings;
    }
    
    public void createCreature(){
        //Sort and create the creatures based on species
        switch (sp) {
            case "Raptor":  
                // change to contcatenate the new dino to the end of array
                Raptor raptor = new Raptor(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                theIsland.add(raptor);
                break;
            case "Rex":  
                // change to contcatenate the new dino to the end of array
                Rex rex = new Rex(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                theIsland.add(rex);
                break;
            case "Parasaur":  
                // change to contcatenate the new dino to the end of array
                Parasaur parasaur = new Parasaur(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                theIsland.add(parasaur);
                break;
            case "Pteranadon":  
                // change to contcatenate the new dino to the end of array
                Pteranadon pteranadon = new Pteranadon(n, sp, hp, stam, oxy, f, w, mel, mov, torp);
                theIsland.add(pteranadon);
                break;
            
            default:
                break;
        }
    }
}